package com.example.myapplicationtrial

import android.content.Intent
import androidx.car.app.Screen
import androidx.car.app.Session
import com.example.myapplicationtrial.TheScreen

class TheSession : Session() {

    override fun onCreateScreen(intent: Intent): Screen {
        return TheScreen(carContext)
    }
}